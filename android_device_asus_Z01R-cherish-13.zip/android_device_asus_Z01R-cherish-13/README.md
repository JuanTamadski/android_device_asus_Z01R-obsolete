Device tree for the Asus Zenfone 5z

Information about the device, build and install instructions can be found [here](http://wiki.lineageos.org/devices/Z01R/)
